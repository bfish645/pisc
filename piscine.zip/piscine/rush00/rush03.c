/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/14 09:48:54 by agraham           #+#    #+#             */
/*   Updated: 2016/08/14 09:54:58 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	rush(int w, int h)
{
	int x;
	int y;

	x = 1;
	y = 1;
	while (y <= h)
	{
		while (x <= w)
		{
			if ((x == 1 && y == 1) || (x == 1 && y == h))
				ft_putchar('A');
			else if ((x == w && y == 1) || (x == w && y == h && w > 1 && h > 1))
				ft_putchar('C');
			else if (x != 1 && y != 1 && x != w && y != h)
				ft_putchar(' ');
			else
				ft_putchar('B');
			x++;
		}
		ft_putchar('\n');
		y++;
		x = 1;
	}
}
