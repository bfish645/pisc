#include <stdio.h>
#include "ft_stock_par.h"
struct	s_stock_par	*ft_param_to_tab(int ac, char **av);

int main(int argc, char** argv)
{
	int i;
	int j;
	struct s_stock_par *array;

	i = 0;
	j = 0; 
	array = ft_param_to_tab(argc, argv);
	
	while(array[i].str != 0)
	{
		printf("size param: %d\nstr: %s\ncopy: %s\n",array[i].size_param, array[i].str, array[i].copy);
		while(array[i].tab[j] != 0){
			printf("i = %d\n",i);
			printf("j = %d\n",j);
			printf("Array element %d: %s\n", j, array[i].tab[j]);
			j++;
		}
		j = 0;
		i++;
	}
}