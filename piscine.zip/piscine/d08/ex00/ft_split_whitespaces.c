/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/20 14:28:57 by agraham           #+#    #+#             */
/*   Updated: 2016/08/20 14:29:05 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

#define BLANK(ws) (ws=='\t'||ws=='\n'||ws==' ')
#define CHAR(p) (('!'<=(p))&&((p)<='~') || p == '\f')

int		ft_word_count(char *str)
{
	int words;

	words = 0;
	while (*str)
	{
		while (BLANK((*str)))
			str++;
		while ((CHAR(*str)))
			str++;
		words++;
	}
	return (words);
}

void	ft_strcpy(char *dest, char *src, int w_start, int end)
{
	int		i;
	int		j;

	i = w_start;
	j = 0;
	while (i <= end)
	{
		dest[j] = src[i];
		i++;
		j++;
	}
	dest[j] = '\0';
}

char	**ft_create_array(char **array, char *str)
{
	int length;
	int i;
	int array_count;

	array_count = 0;
	i = 0;
	while (str[i])
	{
		length = 0;
		while (BLANK(str[i]))
			i++;
		while (CHAR(str[i]))
		{
			i++;
			length++;
		}
		if (length != 0)
		{
			array[array_count] = (char*)malloc((sizeof(char) * length) + 1);
			ft_strcpy(array[array_count], str, (i - length), (i - 1));
			array_count++;
		}
	}
	array[array_count] = 0;
	return (array);
}

char	**ft_split_whitespaces(char *str)
{
	char **array;

	array = (char**)malloc(sizeof(char*) * (ft_word_count(str) + 1));
	return (ft_create_array(array, str));
}
