/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/25 12:28:21 by agraham           #+#    #+#             */
/*   Updated: 2016/08/25 12:28:24 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/ft.h"

void	ft_putfile(char *str, int output, char *name, char *file)
{
	if (errno != 0)
	{
		name = name + 2;
		while (*name != '\0')
		{
			write(2, name, sizeof(char));
			name++;
		}
		write(2, ": ", sizeof(char) * 2);
		while (*file != '\0')
		{
			write(2, file, sizeof(char));
			file++;
		}
		write(2, ": ", sizeof(char) * 2);
	}
	while (*str != '\0')
	{
		write(output, str, sizeof(char));
		str++;
	}
	if (output == 2)
		write(output, "\n", sizeof(char));
}

void	ft_puterr(char *name, char *file)
{
	if (errno == 13)
		ft_putfile("Permission denied", 2, name, file);
	else if (errno == 02)
		ft_putfile("No such file or directory", 2, name, file);
	else if (errno == 62)
		ft_putfile("Too many levels of symbolic links", 2, name, file);
	else if (errno == 21)
		ft_putfile("Is a directory", 2, name, file);
}

int		ft_open_file(char *file, char *name)
{
	int		fd;
	int		ret;
	char	buf[BUF_SIZE + 1];

	fd = open(file, O_RDONLY);
	if (fd == -1)
	{
		ft_puterr(name, file);
		return (-1);
	}
	while ((ret = read(fd, buf, BUF_SIZE)))
	{
		if (ret == -1)
		{
			ft_puterr(name, file);
			return (-1);
		}
		buf[ret] = '\0';
		ft_putfile(buf, 1, name, file);
	}
	return (fd);
}

void	ft_write_input(void)
{
	int		ret;
	char	buf[BUF_SIZE + 1];

	while ((ret = read(0, buf, BUF_SIZE)))
	{
		write(1, buf, ret);
	}
}

int		main(int argc, char **argv)
{
	int i;
	int fd;

	i = 1;
	if (argc == 1)
		ft_write_input();
	while (i < argc)
	{
		if (argv[i][0] == '-')
		{
			ft_write_input();
			if (argv[i + 1])
				if (argv[i + 1][0])
					break ;
		}
		else
		{
			fd = ft_open_file(argv[i], argv[0]);
			if (close(fd) == -1)
				return (1);
		}
		i++;
	}
	return (0);
}
