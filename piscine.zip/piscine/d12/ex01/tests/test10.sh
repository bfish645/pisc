#!/bin/sh

TMPDIRNAME=$(mktemp -d)
BINARYNAME=$RANDOM$RANDOM
trap "rm -rf $TMPDIRNAME" EXIT

cd ..
make all || exit 1
cp ft_cat $TMPDIRNAME/$BINARYNAME
cd $TMPDIRNAME

GREEN=$(printf "\e[32;1m")
RED=$(printf "\e[31;1m")
RESET=$(printf "\e[m")

echo a > a
echo b > b
echo c > c
echo d > d
echo e > e
echo f > f
echo g > g
echo h > h
echo i > i
echo j > j
echo k > k
printf "" > input
printf "a\nb\nc\nd\ne\nf\ng\nh\ni\nj\nk\n" > expect.out
printf "" > expect.err

CMD="./$BINARYNAME a b c d e f g h i j k"

echo $CMD
ulimit -n 10
$CMD 2>user.err <input >user.out
echo diff -U 3 user.out expect.out
diff -U 3 user.out expect.out 
OUTEXIT=$?
echo diff -U 3 user.err expect.err
diff -U 3 user.err expect.err
ERREXIT=$?
( exit $(echo $OUTEXIT + $ERREXIT | bc) ) && echo "${GREEN}Diff [OK]$RESET" || echo "${RED}Diff [KO]$RESET"
