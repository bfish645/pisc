#!/bin/sh

TMPDIRNAME=$(mktemp -d)
BINARYNAME=$RANDOM$RANDOM
trap "rm -rf $TMPDIRNAME" EXIT

cd ..
make all || exit 1
cp ft_cat $TMPDIRNAME/$BINARYNAME
cd $TMPDIRNAME

GREEN=$(printf "\e[32;1m")
RED=$(printf "\e[31;1m")
RESET=$(printf "\e[m")

ln -s loop loop
printf "" > input
printf "" > expect.out
printf "$BINARYNAME: loop: Too many levels of symbolic links\n" > expect.err

CMD="./$BINARYNAME loop"

echo $CMD
$CMD 2>user.err <input >user.out
echo diff -U 3 user.out expect.out
diff -U 3 user.out expect.out 
OUTEXIT=$?
echo diff -U 3 user.err expect.err
diff -U 3 user.err expect.err
ERREXIT=$?
( exit $(echo $OUTEXIT + $ERREXIT | bc) ) && echo "${GREEN}Diff [OK]$RESET" || echo "${RED}Diff [KO]$RESET"
