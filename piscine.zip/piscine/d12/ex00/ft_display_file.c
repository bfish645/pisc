/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/25 09:47:35 by agraham           #+#    #+#             */
/*   Updated: 2016/08/25 09:47:36 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/ft.h"

void	ft_putstr(char *str, int output)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		write(output, &str[i], sizeof(char));
		i++;
	}
	if (output == 2)
		write(output, "\n", sizeof(char));
}

int		ft_open_file(char *file)
{
	int		fd;
	int		ret;
	char	buf[BUF_SIZE + 1];

	fd = open(file, O_RDONLY);
	if (fd == -1)
	{
		ft_putstr("Error opening file", 2);
		return (-1);
	}
	while ((ret = read(fd, buf, BUF_SIZE)))
	{
		if (ret == -1)
		{
			ft_putstr("Error reading", 2);
			return (-1);
		}
		buf[ret] = '\0';
		ft_putstr(buf, 1);
	}
	return (fd);
}

int		main(int argc, char **argv)
{
	int		fd;

	if (argc == 1)
	{
		ft_putstr("File name missing.", 2);
		return (1);
	}
	else if (argc > 2)
	{
		ft_putstr("Too many arguments.", 2);
		return (1);
	}
	else
	{
		fd = ft_open_file(argv[1]);
		if (close(fd) == -1)
			return (1);
	}
	return (0);
}
