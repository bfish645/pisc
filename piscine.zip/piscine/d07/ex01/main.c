#include <stdio.h>
int *ft_range(int min, int max);
void ft_putnbr(int n);

int	main(void)
{
	int min = 1;
	int max = 99;
	int *array;

	array = ft_range(min,max);
	int i = 0;
	while(i < (max - min))
	{
		ft_putnbr(*(array+i));
		i++;
	}
}
