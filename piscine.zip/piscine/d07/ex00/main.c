/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 16:35:01 by agraham           #+#    #+#             */
/*   Updated: 2016/08/17 16:35:03 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <string.h>
char 	*ft_strdup(char *src);
void	ft_putstr(char *str);
void	ft_putchar(char c);

int	main(void)
{
	char src[] = "hello0000000000000";
	char *dest;

	
	//ft_putstr(dest);
	dest = ft_strdup(src);
	ft_putstr(dest);

	//char src2[] = "hello0000000000000";
	//char *dest2;

	//ft_putstr(dest2);
	//dest2 = strdup(src2);
	//ft_putstr(dest2);

	return (0);
}
