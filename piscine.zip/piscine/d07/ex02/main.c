#include <stdio.h>
int ft_ultimate_range(int **array, int min, int max);
void ft_putnbr(int n);
void ft_putchar(char c);

int	main(void)
{
	int min = 1;
	int max = 99;
	int *array;
	int **parray;
	int result;

	parray = &array;

	//result = ft_ultimate_range(parray,min,max);
	int i = 0;
	while(i < (max - min))
	{
		//ft_putnbr(*(array+i));
		ft_putchar('\n');
		i++;
	}
	ft_putchar('\n');
	ft_putnbr(result);
}
