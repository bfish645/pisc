/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespace.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/18 00:22:40 by agraham           #+#    #+#             */
/*   Updated: 2016/08/18 00:22:43 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#define SPACE(c)(c == '\t' || c == ' ' || c == '\n' || c == '\0')

#include <stdlib.h>

void	ft_putnbr(int n);
void	ft_putchar(char c);
void	ft_putstr(char *str);
char	**g_array;
int		g_array_count;

int		ft_count_words(char *str)
{
	int word_count;
	int i;

	i = 0;
	word_count = 0;
	while (str[i] != '\0')
	{
		if (SPACE(str[i]))
		{
			while (SPACE(str[i]))
				i++;
		}
		else
		{
			word_count++;
			while (!SPACE(str[i]))
				i++;
		}
	}
	return (word_count);
}

int		ft_add_to_array(char *str, int i, int w_start, int len)
{
	int j;

	g_array[g_array_count] = (char*)malloc(len + 1);
	if (len > 0)
	{
		j = 0;
		while (w_start < i)
		{
			g_array[g_array_count][j] = str[w_start];
			w_start++;
			j++;
		}
		g_array_count++;
	}
	return (0);
}

char	**ft_split_whitespace(char *str)
{
	int i;
	int len;
	int word_count;
	int array_count;
	int w_start;

	word_count = ft_count_words(str);
	g_array = (char**)malloc(sizeof(char **) * word_count + 1);
	i = 0;
	len = 0;
	array_count = 0;
	while (str[i] != '\0')
	{
		while (SPACE(str[i]))
			i++;
		w_start = i;
		while (!SPACE(str[i]))
		{
			len++;
			i++;
		}
		len = ft_add_to_array(str, i, w_start, len);
	}
	g_array[g_array_count] = 0;
	return (g_array);
}
