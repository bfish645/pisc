char **ft_split_whitespace(char *str);
void ft_putstr(char *str);

int main(void){
	char **res;

	res = ft_split_whitespace(" 443 hi g \t hello41241??  ?\n 321232123123 olleh42124124124414141241  helli2414124124412412142124");

	int i = 0;

	while(i < 8)
	{
		ft_putstr(res[i]);
		ft_putstr("\n");
		i++;
	}
	return (0);
}