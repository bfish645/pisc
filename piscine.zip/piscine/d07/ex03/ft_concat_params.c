/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 21:28:55 by agraham           #+#    #+#             */
/*   Updated: 2016/08/17 21:29:27 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_set_size(int argc, char **argv)
{
	int size;
	int i;
	int x;

	size = 0;
	i = 1;
	x = 0;
	while (i < argc)
	{
		while (argv[i][x] != '\0')
		{
			x++;
			size++;
		}
		x = 0;
		i++;
	}
	return (size);
}

char	*ft_concat_params(int argc, char **argv)
{
	int		size;
	int		i;
	int		j;
	int		x;
	char	*result;

	size = ft_set_size(argc, argv);
	result = (char*)malloc((sizeof(char) * size) + 1);
	i = 1;
	j = 0;
	while (i < argc)
	{
		x = 0;
		while (argv[i][x] != '\0')
		{
			result[j] = argv[i][x];
			j++;
			x++;
		}
		result[j] = '\n';
		j++;
		i++;
	}
	result[j] = '\0';
	return (result);
}
