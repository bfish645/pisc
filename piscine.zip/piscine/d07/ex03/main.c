#include <stdio.h>
char *ft_concat_params(int argc, char **argv);
void ft_putstr(char *str);
void ft_putchar(char c);

int	main(int argc, char **argv)
{
	char *str =  ft_concat_params(argc,argv);
	ft_putstr(str);
	return (0);
}
