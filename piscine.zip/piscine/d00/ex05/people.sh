ldapsearch -Q "uid=z*" cn | grep cn: | sort -fr | cut -c 5-
