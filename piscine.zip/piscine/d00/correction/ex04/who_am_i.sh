RAW=$(ldapwhoami -Q)
echo ${RAW##dn:}
