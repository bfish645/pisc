/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 19:48:28 by agraham           #+#    #+#             */
/*   Updated: 2016/08/11 19:48:30 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strrev(char *str)
{
	int len;
	int halflen;
	int i;

	len = 0;
	i = 0;
	while (str[len] != '\0')
	{
		len++;
	}
	halflen = len / 2;
	while (i < halflen)
	{
		str[len] = str[i];
		str[i] = str[len - i - 1];
		str[len - i - 1] = str[len];
		i++;
	}
	str[len] = '\0';
	return (str);
}
