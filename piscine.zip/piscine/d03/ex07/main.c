
void ft_putstr(char *str);

char *ft_strrev(char *str);

int main()
{
	
	char 	*reversed;
	char string[] = "hello";
	
	reversed = ft_strrev(string);
	ft_putstr(reversed);

	return (0);	
}



