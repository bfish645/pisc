/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_integer_table.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 13:09:31 by agraham           #+#    #+#             */
/*   Updated: 2016/08/12 13:09:53 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_integer_table(int *tab, int size)
{
	int i;
	int i2;
	int temp;

	i = 0;
	i2 = 0;
	temp = 0;
	while (i < size)
	{
		while (i2 < size - 1)
		{
			if (tab[i2] > tab[i2 + 1])
			{
				temp = tab[i2];
				tab[i2] = tab[i2 + 1];
				tab[i2 + 1] = temp;
			}
			i2++;
		}
		i2 = 0;
		i++;
	}
}
