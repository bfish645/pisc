
void ft_putnbr(int i);

void ft_sort_integer_table(int *tab, int size);

int main()
{
	
	int tab[] = {0,-1,10,9,8,7,6,5,4,3,2,1};
	ft_sort_integer_table(tab,12);

	int i = 0;

	while(i < 12){
		ft_putnbr(tab[i]);
		i++;
	}
	return (0);	
}

