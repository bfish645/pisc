

void ft_putstr(char *str);

int main()
{
	int x;
	int y;

	x = 11;
	y = 5;

	
	char	*ptr;
	ptr = "hello";

	
	ft_putstr(ptr);
	
	return (0);	
}