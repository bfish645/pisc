
void ft_putnbr(int i);

int ft_strlen(char *str);

int main()
{
	
	char	*ptr;
	ptr = "hello world";

	
	int i;
	i = ft_strlen(ptr);
	ft_putnbr(i);

	return (0);	
}