/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/10 09:04:24 by agraham           #+#    #+#             */
/*   Updated: 2016/08/10 11:59:09 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int 	ft_putchar(char c)
{
	write(1, &c, 1);
	return (0);
}

int 	ft_nputchar(char c, int n)
{
	int i;

	i = 0;

	while (i < n)
		{
			ft_putchar(c);
			i = i + 1;
		}
	return(0);
}
