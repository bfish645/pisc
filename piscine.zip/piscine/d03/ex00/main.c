void ft_putnbr(int n);

void ft_ft(int *nbr);

int main()
{
	int i;
	int *ptr;

	i = 3;
	ptr = &i;

	ft_putnbr(i);
	ft_ft(ptr);
	ft_putnbr(i);
	return (0);	
}