
void ft_putnbr(int i);

int ft_atoi(char *c);

int main()
{
	
	int result;
	char string[] = "-2147483648";
	result = ft_atoi(string);
	ft_putnbr(result);

	return (0);	
}

