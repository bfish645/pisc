/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 08:57:36 by agraham           #+#    #+#             */
/*   Updated: 2016/08/12 08:57:40 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char *str)
{
	int len;
	int result;
	int sign;

	len = 0;
	result = 0;
	sign = 1;
	if (str[len] == '-')
	{
		sign = -1;
		len++;
	}
	while (str[len] != '\0' && str[len] >= 48 && str[len] <= 57)
	{
		result = result * 10 + (str[len] - 48);
		len++;
	}
	return (result * sign);
}
