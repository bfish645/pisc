void ft_putnbr(int n);

void ft_swap(int *a, int *b);

int main()
{
	int x;
	int y;
	int *a;
	int *b;

	x = 5;
	y = 6;

	a = &x;
	b = &y;


	ft_putnbr(x);
	ft_putnbr(y);
	ft_swap(&x,&y);
	ft_putnbr(x);
	ft_putnbr(y);
	return (0);	
}