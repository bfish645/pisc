void ft_putnbr(int n);

void ft_ultimate_div_mod(int *a, int *b);

int main()
{
	int x;
	int y;

	x = 11;
	y = 5;

	

	
	ft_ultimate_div_mod(&x,&y);
	ft_putnbr(x);
	ft_putnbr(y);
	
	return (0);	
}