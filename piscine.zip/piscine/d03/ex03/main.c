void ft_putnbr(int n);

void ft_div_mod(int a, int b, int *div, int *mod);

int main()
{
	int x;
	int y;
	int c;
	int d; 

	x = 11;
	y = 5;

	

	
	ft_div_mod(x,y,&c,&d);
	ft_putnbr(c);
	ft_putnbr(d);
	return (0);	
}