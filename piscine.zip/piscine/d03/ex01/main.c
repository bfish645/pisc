void ft_putnbr(int n);

void ft_ultimate_ft(int *********nbr);

int main()
{
	int i;
	int *nbr;
	int **nbr2;
	int ***nbr3;
	int ****nbr4;
	int *****nbr5;
	int ******nbr6;
	int *******nbr7;
	int ********nbr8;
	int *********nbr9;


	i = 3;
	
	nbr = &i;
	nbr2 = &nbr;
	nbr3 = &nbr2;
	nbr4 = &nbr3;
	nbr5 = &nbr4;
	nbr6 = &nbr5;
	nbr7 = &nbr6;
	nbr8 = &nbr7;
	nbr9 = &nbr8;

	ft_putnbr(i);
	ft_ultimate_ft(nbr9);
	ft_putnbr(i);
	return (0);	
}