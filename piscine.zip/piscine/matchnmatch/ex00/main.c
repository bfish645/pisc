/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/20 20:08:54 by agraham           #+#    #+#             */
/*   Updated: 2016/08/20 20:12:18 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int match(char *s1, char *s2);
int main(int argc, char **argv)
{
	if (argc == 3)
		printf("Return result: %d", match(argv[1], argv[2]));
	return (0);
}
