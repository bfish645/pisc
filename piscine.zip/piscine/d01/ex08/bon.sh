ldapsearch -Q 'cn=*bon*' | grep 'bon' | grep '^cn' | wc | awk '{print $1}'0
