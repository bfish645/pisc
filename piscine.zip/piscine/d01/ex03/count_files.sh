find . -name "*" | wc | awk '{print $1}'
