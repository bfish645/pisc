A=$(echo $FT_NBR1 | tr \'\\'\"'\?\! 01234)
B=$(echo $FT_NBR2 | tr mrdoc 01234)

echo "obase=13;ibase=5;$A+$B" | bc | tr 0123456789ABC gtaio\ luSnemf
