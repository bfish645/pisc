/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_button.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/19 10:00:25 by agraham           #+#    #+#             */
/*   Updated: 2016/08/19 10:00:58 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_button(int i, int j, int k)
{
	if (i < j && i > k)
		return (i);
	else if (i > j && i < k)
		return (i);
	else if (j < i && j > k)
		return (j);
	else if (j > i && j < k)
		return (j);
	else if (k < j && k > i)
		return (k);
	else if (k > j && k < i)
		return (k);
	else if (i == j)
		return (i);
	else if (j == k)
		return (j);
	else if (k == i)
		return (k);
	return (0);
}
