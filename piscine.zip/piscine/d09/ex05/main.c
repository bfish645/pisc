#include <stdio.h>

int	ft_button(int i, int j, int k);

int	main(void)
{
	printf("%d\n",ft_button(1,2,1));
	printf("%d\n",ft_button(0,20,-95));
	printf("%d\n",ft_button(51123,44414,9999));
	printf("%d\n",ft_button(67,-99,10));
	printf("%d\n",ft_button(18,12,53));
	printf("%d\n",ft_button(1984,2067,3313));
	printf("%d\n",ft_button(3213,2231,331));
	return (0);
}
