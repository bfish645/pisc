IP=$(/sbin/ifconfig -a | grep "inet " | tail -1 | awk '{print $2}')
if [ -n "$IP" ]; then
	echo $IP
else
	echo "Je suis perdu!"
fi