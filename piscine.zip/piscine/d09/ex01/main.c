void ft_takes_place(int hour);

int	main(void){
	ft_takes_place(0);
	ft_takes_place(1);
	ft_takes_place(2);
	ft_takes_place(3);
	ft_takes_place(4);
	ft_takes_place(5);
	ft_takes_place(6);
	ft_takes_place(7);
	ft_takes_place(8);
	ft_takes_place(9);
	ft_takes_place(10);
	ft_takes_place(11);
	ft_takes_place(12);
	ft_takes_place(13);
	ft_takes_place(14);
	ft_takes_place(15);
	ft_takes_place(16);
	ft_takes_place(17);
	ft_takes_place(18);
	ft_takes_place(19);
	ft_takes_place(20);
	ft_takes_place(21);
	ft_takes_place(22);
	ft_takes_place(23);
	ft_takes_place(24);
}