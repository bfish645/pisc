/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/18 19:44:38 by agraham           #+#    #+#             */
/*   Updated: 2016/08/18 19:45:07 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_takes_place(int hour)
{
	char	*preamble;
	char	*fap;
	char	*tap;
	int		from;
	int		to;

	preamble = "THE FOLLOWING TAKES PLACE BETWEEN";
	from = hour > 12 ? hour - 12 : hour;
	fap = hour > 11 && hour < 24 ? "P.M." : "A.M.";
	to = hour + 1 > 12 ? hour + 1 - 12 : hour + 1;
	tap = hour + 1 > 11 && hour + 1 < 24 ? "P.M." : "A.M.";
	if (hour + 1 > 24)
		to = hour + 1 - 24;
	if (hour == 0)
		from = 12;
	printf("%s %d.00 %s AND %d.00 %s\n", preamble, from, fap, to, tap);
}
