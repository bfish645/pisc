alias rm="echo Donnie saved"
