/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/19 13:22:16 by agraham           #+#    #+#             */
/*   Updated: 2016/08/19 13:22:18 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int g_i;
int g_j;
int g_tf_i;
int g_tf_j;
char *g_to_find[] = {"president", "attack", "powers", 0};


char	*ft_strlowcase(char *str)
{
	int g_i;

	g_i = 0;
	while (str[g_i] != '\0')
	{
		if (str[g_i] >= 65 && str[g_i] <= 90)
			str[g_i] = str[g_i] + 32;
		g_i++;
	}
	return (str);
}

int ft_init_counters()
{
	g_i = 1;
	g_j = 0;
	g_tf_i = 0;
	g_tf_j = 0;

	return (0);
}

void ft_reset_counters(int type)
{
	if(type == 1)
	{
		g_j = 0;
		g_tf_j = 0;
		g_tf_i++;
	}
	if(type == 0)
	{
		g_j = 0;
		g_tf_i = 0;
		g_i++;
	}
}
int	ft_search(int argc, char **array)
{
	int match;

	match = ft_init_counters();
	while (g_i < argc)
	{
		while (array[g_i][g_j] != '\0')
		{
			while (array[g_i][g_j] == ' ' && array[g_i][g_j+1] != '\0')
				g_j++;
			while(g_to_find[g_tf_i] != 0 && match == 0)
			{
				while(g_to_find[g_tf_i][g_tf_j] != '\0')
				{
					if(g_to_find[g_tf_i][g_tf_j] == array[g_i][g_j])
					{
						g_j++;
						g_tf_j++;
					}else
					{
						match = 0;
						break;
					}
					match = 1;
				}
				ft_reset_counters(1);
			}
			g_j++;
		}
		ft_reset_counters(0);
	}
	return (match);
}

int	main(int argc, char **argv)
{
	

	if(ft_search(argc, argv) == 1){
		write(1, "Alert!\n", 7);
	}
}
