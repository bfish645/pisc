char	*ft_rot42(char *str);
void	ft_putstr(char *str);

int		main(void)
{
	char rot[] = "Hello my name is Alex!!!\n";
	ft_putstr(ft_rot42(rot));
	return (0);
}