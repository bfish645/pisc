void ft_destroy(char ***c);
void ft_putchar(char c);

int	main(void)
{
	char *array[] = {"hello","world","hello"};
	char **pointer = array;
	char ***pointer1 = &pointer;

	int i = 0;
	int x = 0;
	while(i < 3)
	{
		
		while(array[i][x] != '\0')
		{
			ft_putchar(array[i][x]);
			x++;
		}
		x = 0;
		i++;
	}
	ft_destroy(pointer1);
}