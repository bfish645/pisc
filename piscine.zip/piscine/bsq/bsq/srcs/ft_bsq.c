/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bsq.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/30 09:44:13 by spiro             #+#    #+#             */
/*   Updated: 2016/08/30 09:44:32 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		**ft_create_temp(char **map, int *lengths)
{
	int			**temp;
	int			i;
	int			j;

	i = 0;
	j = 0;
	temp = (int**)malloc(sizeof(int*) * lengths[2]);
	while (i < (lengths[2] - 1))
	{
		temp[i] = (int*)malloc(sizeof(int) * (lengths[1] + 1));
		while (j < (lengths[1]))
		{
			if (map[i][j] == g_inf[0])
				temp[i][j] = 1;
			else
				temp[i][j] = 0;
			j++;
		}
		i++;
		j = 0;
	}
	return (temp);
}

int		ft_find_min(int **map, int i, int j)
{
	int		min;

	min = 99999;
	if (map[i - 1][j] < min)
		min = map[i - 1][j];
	if (map[i - 1][j - 1] < min)
		min = map[i - 1][j - 1];
	if (map[i][j - 1] < min)
		min = map[i][j - 1];
	return (min);
}

int		**ft_process_temp(int **map, int *lengths)
{
	int		i;
	int		j;

	i = 1;
	j = 1;
	while (i < (lengths[2] - 1))
	{
		while (j < (lengths[1]))
		{
			if (map[i][j] != 0)
				map[i][j] = (ft_find_min(map, i, j) + 1);
			j++;
		}
		i++;
		j = 1;
	}
	return (map);
}

void	ft_fill_square(t_max max, int *lengths, int **map)
{
	int			i;
	int			j;

	i = 0;
	j = 0;
	while (i < (lengths[2] - 1))
	{
		while (j < (lengths[1]))
		{
			if (i >= (max.max_i - (max.max - 1)) && i <= max.max_i &&
				(j >= (max.max_j - (max.max - 1)) && j <= max.max_j))
				ft_putchar(g_inf[2]);
			else if (map[i][j] == 0)
				ft_putchar(g_inf[1]);
			else
				ft_putchar(g_inf[0]);
			j++;
		}
		i++;
		ft_putchar('\n');
		j = 0;
	}
}

void	ft_complete_bsq(int **map, int *lengths)
{
	int			i;
	int			j;
	t_max		max;

	i = 0;
	j = 0;
	max.max = 0;
	max.max_j = 0;
	max.max_i = 0;
	while (i < (lengths[2] - 1))
	{
		while (j < (lengths[1]))
		{
			if (map[i][j] > max.max)
			{
				max.max_i = i;
				max.max_j = j;
				max.max = map[i][j];
			}
			j++;
		}
		i++;
		j = 0;
	}
	ft_fill_square(max, lengths, map);
}
