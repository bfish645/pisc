/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_array.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/31 09:26:27 by spiro             #+#    #+#             */
/*   Updated: 2016/08/31 09:26:30 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		*ft_stdi_get_lengths(t_list *list)
{
	int			*lengths;
	int			length;

	length = 0;
	lengths = (int*)malloc(sizeof(int) * 3);
	lengths = ft_init_lengths(lengths);
	while (list)
	{
		if (list->data != '\n' && lengths[2] == 0)
			lengths[0]++;
		else if (list->data != '\n' && lengths[2] == 1)
			lengths[1]++;
		else if (list->data != '\n')
			length++;
		else if (list->data == '\n')
		{
			lengths[2]++;
			if (length != lengths[1] && lengths[2] != 2)
				return (0);
			length = 0;
		}
		list = list->next;
	}
	return (lengths);
}

int		ft_validate_stdi_input(t_list *list, int *lengths)
{
	int		count;
	int		lines;

	count = 0;
	lines = 0;
	while (list)
	{
		if (count < lengths[0] - 3)
			lines = 10 * lines + (list->data - 48);
		if (count == lengths[0] - 3)
			g_inf[0] = list->data;
		else if (count == lengths[0] - 2)
			g_inf[1] = list->data;
		else if (count == lengths[0] - 1)
			g_inf[2] = list->data;
		if (count > lengths[0] && list->data != g_inf[0] &&
			list->data != g_inf[1] && list->data != '\n')
			return (0);
		count++;
		list = list->next;
	}
	return (lines == (lengths[2] - 1) ? 1 : 0);
}

int		**ft_create_stdi_temp(t_list *list, int *lengths)
{
	int			**temp;
	int			i;
	int			j;

	i = 0;
	j = 0;
	list = ft_list_at(list, lengths[0] + 2);
	temp = (int**)malloc(sizeof(int*) * lengths[2]);
	while (i < (lengths[2]))
		temp[i++] = (int*)malloc(sizeof(int) * (lengths[1] + 1));
	i = 0;
	while (list)
	{
		if (list->data == '\n')
		{
			i++;
			j = 0;
		}
		else if (list->data == g_inf[0])
			temp[i][j++] = 1;
		else
			temp[i][j++] = 0;
		list = list->next;
	}
	return (temp);
}

int		ft_process_stdi(t_list *list)
{
	int		*lengths;
	int		**temp;

	lengths = ft_stdi_get_lengths(list);
	if (lengths == 0 || lengths[0] < 4)
	{
		write(2, "map error\n", 10);
		return (0);
	}
	if (ft_validate_stdi_input(list, lengths) == 0)
	{
		write(2, "map error\n", 10);
		return (0);
	}
	temp = ft_create_stdi_temp(list, lengths);
	temp = ft_process_temp(temp, lengths);
	ft_complete_bsq(temp, lengths);
	free(lengths);
	return (0);
}
