/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/29 09:38:12 by spiro             #+#    #+#             */
/*   Updated: 2016/08/29 09:38:15 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_free_map(int **temp, int *lengths)
{
	int i;

	i = 0;
	while (i < (lengths[2] - 1))
	{
		free(temp[i]);
		i++;
	}
	free(temp);
}

void	ft_bsq(char **map, int *lengths)
{
	int		**temp;

	temp = ft_create_temp(map, lengths);
	temp = ft_process_temp(temp, lengths);
	ft_complete_bsq(temp, lengths);
	ft_free_map(temp, lengths);
}

int		main(int argc, char **argv)
{
	int		i;
	char	buf;
	int		ret;
	t_list	*list;

	i = 1;
	list = NULL;
	if (argc >= 2)
	{
		while (i < argc)
		{
			ft_process_input(argv[i]);
			i++;
		}
	}
	else if (argc == 1)
	{
		while ((ret = read(0, &buf, 1)))
			ft_list_push_back(&list, buf);
		ft_process_stdi(list);
		ft_list_clear(&list);
	}
	return (0);
}
