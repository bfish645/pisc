/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/29 11:02:22 by spiro             #+#    #+#             */
/*   Updated: 2016/08/29 11:02:46 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_open_file(char *file)
{
	int		fd;

	fd = open(file, O_RDONLY);
	if (fd == -1)
	{
		write(2, "open() error\n", 13);
		return (0);
	}
	return (fd);
}

int		ft_close_file(int fd)
{
	if (close(fd) == -1)
	{
		write(2, "close() error\n", 14);
		return (0);
	}
	return (0);
}
