/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elee <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 18:37:45 by elee              #+#    #+#             */
/*   Updated: 2016/08/27 19:50:13 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

t_list		*ft_create_elem(char data)
{
	t_list	*tmp;

	tmp = (t_list*)malloc(sizeof(t_list));
	if (tmp)
	{
		tmp->data = data;
		tmp->next = NULL;
	}
	return (tmp);
}

void		ft_list_push_back(t_list **begin_list, char data)
{
	t_list	*list;

	list = *begin_list;
	if (list == NULL)
		*begin_list = ft_create_elem(data);
	else
	{
		while (list->next != NULL)
			list = list->next;
		list->next = ft_create_elem(data);
	}
}

t_list		*ft_list_at(t_list *begin_list, unsigned int nbr)
{
	unsigned int	i;
	t_list			*current;

	i = 1;
	current = begin_list;
	while (i < nbr)
	{
		if (current == NULL)
			return (NULL);
		current = current->next;
		i++;
	}
	return (current);
}

void		ft_list_clear(t_list **begin_list)
{
	t_list *list;

	while (*begin_list)
	{
		list = *begin_list;
		*begin_list = (*begin_list)->next;
		free(list);
	}
}
