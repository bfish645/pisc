/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/29 09:39:40 by spiro             #+#    #+#             */
/*   Updated: 2016/08/29 09:39:42 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <stdlib.h>

void				ft_putchar(char c);
void				ft_putstr(char *c);
void				ft_putnbr(int nb);
int					ft_open_file(char *file);
int					ft_close_file(int fd);
int					ft_process_input(char *file);
void				ft_bsq(char **map, int *lengths);
typedef struct		s_list
{
	struct s_list	*next;
	char			data;
}					t_list;
void				ft_list_push_back(t_list **begin_list, char data);
int					ft_process_stdi(t_list *list);
void				ft_list_clear(t_list **begin_list);
t_list				*ft_list_at(t_list *begin_list, unsigned int nbr);
int					**ft_process_temp(int **map, int *lengths);
void				ft_complete_bsq(int **map, int *lengths);
int					*ft_init_lengths(int *lengths);
int					**ft_process_temp(int **map, int *lengths);
int					**ft_create_temp(char **map, int *lengths);
void				ft_complete_bsq(int **map, int *lengths);

char				g_inf[3];
typedef struct		s_max
{
	int				max;
	int				max_i;
	int				max_j;
}					t_max;
#endif
