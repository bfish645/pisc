#include "ft_list.h"
t_list	*ft_list_remove_if(t_list **begin_list, void *data_ref, int (*cmp)());
#include <stdio.h>

void	ft_print_data(void *hello)
{
	printf("Data: %s\n", hello);
}

int		ft_strcmp(char *s1, char *s2)
{
	unsigned char	a;
	unsigned char	b;
	int				i;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		a = s1[i];
		b = s2[i];
		if (a != b)
			return (a - b);
		i++;
	}
	return (0);
}

int main(void)
{	
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("shithead");
	t_list *last2 = ft_create_elem("bird");

	list->next = next;
	next->next = last;
	last->next = last2;
	ft_list_remove_if(&list, "hello", &ft_strcmp);

	while(list)
	{
		printf("list data %s\n", list->data);
		list = list->next;
	}

}