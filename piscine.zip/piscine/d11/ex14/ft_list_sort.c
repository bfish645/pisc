/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_sort.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/24 13:49:29 by agraham           #+#    #+#             */
/*   Updated: 2016/08/24 13:50:21 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

int		g_done;

void	ft_list_sort(t_list **begin_list, int (*cmp)())
{
	t_list	**start;
	t_list	*current;
	t_list	*next;

	g_done = 0;
	while (!g_done)
	{
		start = begin_list;
		current = *begin_list;
		next = (*begin_list)->next;
		g_done = 1;
		while (next)
		{
			if ((*cmp)(current->data, next->data) > 0)
			{
				current->next = next->next;
				next->next = current;
				*start = next;
				g_done = 0;
			}
			start = &current->next;
			current = next;
			next = next->next;
		}
	}
}
