#include <stdio.h>
#include "ft_list.h"
t_list	*ft_create_elem(void *data);

int	main(void){
	t_list *list = ft_create_elem("hello");
	printf("list.data: %s\n", list.list);
	printf("list.next: %s\n", list.next);
	return(0);
}