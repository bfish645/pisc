#include <stdio.h>
#include "ft_list.h"
void	ft_list_push_front(t_list **begin_list, void *data);

int		main(void)
{
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	list->next = next;
	
	ft_list_push_front(&list, "shithead");

	while (list)
	{
		printf("list.data: %s\n", list->data);
		list = list->next;
	}
	return(0);

}