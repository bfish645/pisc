#include <stdio.h>
#include "ft_list.h"
int	ft_list_size(t_list *begin_list);

int		main(void)
{
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("shithead");
	list->next = next;
	next->next = last;
	printf("count: %d\n",ft_list_size(list));
	while (list)
	{
		printf("list.data: %s\n", list->data);
		list = list->next;
	}
	return(0);
}