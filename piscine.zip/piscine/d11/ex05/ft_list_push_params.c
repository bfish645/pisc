/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_params.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 17:37:45 by agraham           #+#    #+#             */
/*   Updated: 2016/08/23 17:37:47 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list	*ft_list_push_params(int ac, char **av)
{
	t_list	*first;
	t_list	*prev;
	t_list	*next;

	first = ft_create_elem(av[ac-- - 1]);
	prev = first;
	while (ac > 1)
	{
		next = ft_create_elem(av[ac - 1]);
		prev->next = next;
		prev = next;
		ac--;
	}
	return (first);
}
