#include "ft_list.h"
#include <stdio.h>
t_list	*ft_list_at(t_list *begin_list, unsigned int i);

int  main()
{
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("shithead");

	list->next = next;
	next->next = last;
	//int a = 0;
	unsigned int b = 1;
	unsigned int c = 2;
	unsigned int d = 3;
	int e = 4; 

	//t_list *ta = ft_list_at(&list, a);
	t_list *tb = ft_list_at(list, b);
	t_list *tc = ft_list_at(list, c);
	t_list *td = ft_list_at(list, d);
	t_list *te = ft_list_at(list, e);

	//printf("List at %d  = %s\n", a, ta->data);
	printf("List at %d  = %s\n", b, tb->data);
	printf("List at %d  = %s\n", c, tc->data);
	printf("List at %d  = %s\n", d, td->data);
	printf("List at %d  = %p\n", e, te);
}