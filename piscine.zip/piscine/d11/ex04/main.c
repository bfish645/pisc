#include <stdio.h>
#include "ft_list.h"
t_list	*ft_list_last(t_list *begin_list);

int		main(void)
{
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("dickpic");
	list->next = next;
	next->next = last;
	printf("last: %s\n",ft_list_last(list)->data);
	return(0);
}