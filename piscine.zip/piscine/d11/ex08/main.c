#include "ft_list.h"
#include <stdio.h>
t_list	ft_list_reverse(t_list **begin_list);

int  main()
{
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("shithead");
	t_list *last2 = ft_create_elem("bird");

	list->next = next;
	next->next = last;
	last->next = last2;
	
	ft_list_reverse(&list);

	while(list)
	{
		printf("Array element data: %s\n",list->data);
		list = list->next;
	}

}