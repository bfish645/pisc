#include <stdio.h>
#include "ft_list.h"
void	ft_list_push_back(t_list **begin_list, void *data);

int		main(void)
{
	t_list *list;

	list = NULL;
	
	ft_list_push_back(&list, "shithead");

	while (list)
	{
		printf("list.data: %s\n", list->data);
		list = list->next;
	}
	return(0);

}