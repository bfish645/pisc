#include "ft_list.h"
#include <stdio.h>
void ft_list_foreach(t_list *begin_list, void (*f)(void *));
void ft_putstr(char *str);

void	ft_print_data(void *hello)
{
	printf("Data: %s\n", hello);
}

int  main()
{
	t_list *list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("shithead");
	t_list *last2 = ft_create_elem("bird");

	list->next = next;
	next->next = last;
	last->next = last2;
	
	ft_list_foreach(list,&ft_print_data);

}