#include "ft_list.h"
#include <stdio.h>
t_list	ft_list_clear(t_list **begin_list);

int  main()
{
	t_list *list;

	list = NULL;

	list = ft_create_elem("hello");
	t_list *next = ft_create_elem("world");
	t_list *last = ft_create_elem("shithead");
	list->next = next;
	next->next = last;
	printf("List beforeL%p\n", list);
	while (list)
	{
		printf("list.data: %s\n", list->data);
		list = list->next;
	}
	ft_list_clear(&list);
	printf("List is NULL%p\n", list);

	while (list)
	{
		printf("list.data: %s\n", list->data);
		list = list->next;
	}
	
}