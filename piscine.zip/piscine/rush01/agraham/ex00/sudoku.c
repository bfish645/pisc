/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 11:23:22 by agraham           #+#    #+#             */
/*   Updated: 2016/08/21 11:23:23 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
//REMOVE ME
#include <stdio.h>

int ft_complete_sudoku(int **puzzle, int row, int col);


void ft_print_sudoku(int **puzzle)
{
	int i;
	int j;
	char c;

	i = 0;
	j = 0;

	while (i < 9)
	{
		while (j < 9){
			c = puzzle[i][j] + 48;
			write(1, &c, sizeof(c));
			write(1, " ", sizeof(c));
			if (j == 8)
				write(1, "\n", 1);
			j++;
		}
		i++;
		j = 0;
	}
}

int ft_validate_number(int **puzzle, int row, int col, int number)
{
	int rowStart = (row/3) * 3;
	int colStart = (col/3) * 3;
	int i, j;

	for(i=0; i<9; ++i)
	{
	    if (puzzle[row][i] == number) 
	    	return 0;
	    if (puzzle[i][col] == number) 
	    	return 0;
	    if (puzzle[rowStart + (i%3)][colStart + (i/3)] == number) 
	    	return 0;
	}
	return 1;
}

int ft_find_next_number(int **puzzle, int row, int col)
{
    if((col+1)<9) 
    	return ft_complete_sudoku(puzzle, row, col+1);
    else if((row+1)<9) 
    	return ft_complete_sudoku(puzzle, row+1, 0);
    else return 1;
}

int ft_find_number(int **puzzle, int row, int col, int number)
{
	number = 0;
	while(number < 9)
	{
	    if(ft_validate_number(puzzle, row, col, number+1))
	    {
	        puzzle[row][col] = number+1;
	        if((col+1)<9)
	        {
	            if(ft_complete_sudoku(puzzle, row, col +1)) 
	            	return 1;
	            else puzzle[row][col] = 0;
	        }
	        else if((row+1)<9)
	        {
	            if(ft_complete_sudoku(puzzle, row+1, 0)) 
	            	return 1;
	            else puzzle[row][col] = 0;
	        }
	        else 
	        	return 1;
	    }
	    number++;
	}
	return(0);
}
int ft_complete_sudoku(int **puzzle, int row, int col)
{
    int number;

    number = 0;
    if(row<9 && col<9)
    {
        if(puzzle[row][col] != 0)
            return ft_find_next_number(puzzle,row, col);
        else
        {
         	if(ft_find_number(puzzle, row, col, number))
         		return (1);
        }
        return (0);
    }
    else 
    	return (1);
}

int ft_validate_sudoku(int argc, char **argv)
{
	int i;
	int j;
	int char_count;

	i = 1;
	j = 0;
	char_count = 0;
	if (argc == 10)
	{
		while (i < 10){
			while (argv[i][j] != '\0')
			{
				if(argv[i][j] == '.' || (argv[i][j] >= '1' && argv[i][j] <= '9'))
					char_count++;
				else
					return (0);
				j++;
			}
			if(char_count != 9)
				return (0);
			i++;
			j = 0;
			char_count = 0;
		}
		return (1);
	}
	else
		return (0);	
	return (0);
}

int **ft_parse_sudoku(char **argv)
{
   	int i;
	int j;
	int **puzzle;
	puzzle = (int**)malloc(sizeof(int*) * 9);

	i = 1;
	j = 0;
	while (i <= 9)
	{
		puzzle[i - 1] = (int*)malloc(sizeof(int) * 9);
		while (argv[i][j] != '\0'){
			puzzle[i - 1][j] = (argv[i][j] == '.') ? 0 : argv[i][j] - 48;
			j++;
		}
		i++;
		j = 0;
	}
	i = 0;
	return (puzzle);
}

int main(int argc, char **argv)
{
	int **puzzle;

	if(ft_validate_sudoku(argc, argv))
	{
		puzzle = ft_parse_sudoku(argv);
		if(ft_complete_sudoku(puzzle,0,0)){
			ft_print_sudoku(puzzle);
		}
		else
			write(1, "Error\n",6);
	}
	else{
		(void)puzzle;
		write(1, "Error\n",6);
	}
	return (0);
}
