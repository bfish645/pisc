/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 11:23:22 by agraham           #+#    #+#             */
/*   Updated: 2016/08/21 11:23:23 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "sudoku.h"

int	ft_complete_sudoku(int **puzzle, int row, int col, int **puzzle2)
{
	int number;

	number = 0;
	if (row < 9 && col < 9)
	{
		if (puzzle[row][col] != 0)
			return (ft_find_next_number(puzzle, row, col, puzzle2));
		else
		{
			if (ft_find_number(puzzle, row, col, puzzle2))
				return (1);
		}
		return (0);
	}
	else
		return (1);
}

int	ft_validate_sudoku(int argc, char **argv, int char_count)
{
	int i;
	int j;

	i = 1;
	j = 0;
	if (argc == 10)
	{
		while (i < 10)
		{
			while (argv[i][j] != '\0')
			{
				if (argv[i][j] == '.' || (argv[i][j] > 48 && argv[i][j] < 58))
					char_count++;
				else
					return (0);
				j++;
			}
			if (char_count != 9)
				return (0);
			i++;
			j = 0;
			char_count = 0;
		}
	}
	return (1);
}

int	**ft_parse_sudoku(char **argv)
{
	int i;
	int j;
	int **puzzle;

	puzzle = (int**)malloc(sizeof(int*) * 9);
	i = 1;
	j = 0;
	while (i <= 9)
	{
		puzzle[i - 1] = (int*)malloc(sizeof(int) * 9);
		while (argv[i][j] != '\0')
		{
			puzzle[i - 1][j] = (argv[i][j] == '.') ? 0 : argv[i][j] - 48;
			j++;
		}
		i++;
		j = 0;
	}
	i = 0;
	return (puzzle);
}

int	ft_check_alternate_solution(int **puzzle1, int **puzzle2, char **argv)
{
	puzzle2 = ft_parse_sudoku(argv);
	if (ft_complete_sudoku(puzzle2, 0, 0, puzzle1))
		return (1);
	else
		return (0);
}

int	main(int argc, char **argv)
{
	int **puzzle1;
	int **puzzle2;
	int char_count;

	puzzle2 = NULL;
	char_count = 0;
	if (ft_validate_sudoku(argc, argv, char_count))
	{
		puzzle1 = ft_parse_sudoku(argv);
		if (ft_complete_sudoku(puzzle1, 0, 0, puzzle2))
			ft_print_sudoku(puzzle1);
		else
			write(1, "Error\n", 6);
	}
	else
	{
		(void)puzzle1;
		(void)puzzle2;
		write(1, "Error\n", 6);
	}
	return (0);
}
