/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anbarbos <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 21:59:17 by anbarbos          #+#    #+#             */
/*   Updated: 2016/08/21 22:09:05 by anbarbos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SUDOKU_H
# define SUDOKU_H
# include <unistd.h>
# include <stdlib.h>

int		ft_complete_sudoku(int **puzzle, int row, int col, int **puzzle2);
int		ft_validate_sudoku(int argc, char **argv, int char_count);
int		**ft_parse_sudoku(char **argv);
int		ft_check_alternate_solution(int **puzzle1, int **puzzle2, char **argv);
void	ft_print_sudoku(int **puzzle);
int		ft_validate_number(int **puzzle, int rowcol, int number, int **puzzle2);
int		ft_find_next_number(int **puzzle, int row, int col, int **puzzle2);
int		ft_find_number(int **puzzle, int row, int col, int **puzzle2);
#endif
