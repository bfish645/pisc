/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sudoku_helper.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 21:11:47 by agraham           #+#    #+#             */
/*   Updated: 2016/08/21 21:53:45 by sberlant         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "sudoku.h"

void	ft_print_sudoku(int **puzzle)
{
	int		i;
	int		j;
	char	c;

	i = 0;
	j = 0;
	while (i < 9)
	{
		while (j < 9)
		{
			c = puzzle[i][j] + 48;
			write(1, &c, sizeof(c));
			if (j == 8)
				write(1, "\n", 1);
			else
				write(1, " ", sizeof(c));
			j++;
		}
		i++;
		j = 0;
	}
}

int		ft_validate_number(int **puzzle, int rowcol, int number, int **puzzle2)
{
	int		row;
	int		col;
	int		row_start;
	int		col_start;
	int		i;

	i = 0;
	row = rowcol / 10;
	col = rowcol % 10;
	row_start = (row / 3) * 3;
	col_start = (col / 3) * 3;
	while (++i < 9)
	{
		if (puzzle2)
			if (number == puzzle2[row][i] && col == 1 && row == 1)
				return (0);
		if (puzzle[row][i] == number)
			return (0);
		if (puzzle[i][col] == number)
			return (0);
		if (puzzle[row_start + (i % 3)][col_start + (i / 3)] == number)
			return (0);
	}
	return (1);
}

int		ft_find_next_number(int **puzzle, int row, int col, int **puzzle2)
{
	if ((col + 1) < 9)
		return (ft_complete_sudoku(puzzle, row, (col + 1), puzzle2));
	else if ((row + 1) < 9)
		return (ft_complete_sudoku(puzzle, (row + 1), col, puzzle2));
	else
		return (1);
}

int		ft_find_number(int **puzzle, int row, int col, int **puzzle2)
{
	int number;

	number = 0;
	while (number < 9)
	{
		if (ft_validate_number(puzzle, ((row * 10) + col), number + 1, puzzle2))
		{
			puzzle[row][col] = number + 1;
			if ((col + 1) < 9)
				if (ft_complete_sudoku(puzzle, row, col + 1, puzzle2))
					return (1);
				else
					puzzle[row][col] = 0;
			else if ((row + 1) < 9)
				if (ft_complete_sudoku(puzzle, row + 1, 0, puzzle2))
					return (1);
				else
					puzzle[row][col] = 0;
			else
				return (1);
		}
		number++;
	}
	return (0);
}
