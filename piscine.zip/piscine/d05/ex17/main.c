#include <stdio.h>
#include <string.h>

void	ft_putstr(char *string);
void	ft_putchar(char c);
char	*ft_strncat(char *str1, char *str2, int nb);

int		main(void)
{
	
	return (0);
}
