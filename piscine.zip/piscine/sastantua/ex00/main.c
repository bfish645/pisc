void sastantua(int size);

int main(void)
{
	sastantua(2);
}
