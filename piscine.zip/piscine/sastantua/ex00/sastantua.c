/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/13 15:56:42 by agraham           #+#    #+#             */
/*   Updated: 2016/08/13 16:04:31 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

int g_block;
int g_rows;
int g_width;
int g_rc;
int g_loc;
int g_spaces;
int g_spacecount;
int g_space_increment;
int g_width_increment;
int g_width_count;
int g_rc;
int g_door_width;
int g_ds;
int g_de;

void	ft_init_counters(int size)
{
	int i;

	g_block = 1;
	g_rows = 3;
	g_width = 3;
	g_rc = 1;
	g_loc = 1;
	g_spaces = 3;
	g_space_increment = 3;
	g_width_count = 0;
	g_width_increment = 4;
	i = 2;
	g_spacecount = 0;
	while (i <= size)
	{
		if (i == 2 || i == 3)
			g_space_increment += 2;
		else if (i % 2 == 0)
			g_space_increment += 2;
		else
			g_space_increment += 1;
		g_spaces += g_space_increment;
		i++;
	}
}

void	ft_set_door_properties(int size)
{
	g_door_width = 1;
	if (size > 2)
	{
		g_door_width = 3;
		if (size > 3 && size % 2 == 1)
		{
			g_door_width = g_block;
		}
		else
		{
			g_door_width = g_block - 1;
		}
	}
	g_ds = (g_width / 2) - (g_door_width / 2);
	g_de = (g_width / 2) + (g_door_width / 2) + 1;
}

void	ft_print(int size)
{
	char p;

	ft_set_door_properties(size);
	if (g_loc == 1)
		p = '/';
	else if (g_loc == g_width)
		p = '\\';
	else
	{
		p = '*';
		if (g_block == size)
			if ((size % 2 == 0 && g_rc > 3) || (size % 2 == 1 && g_rc > 2))
				if (g_loc > g_ds && g_loc <= g_de)
				{
					p = '|';
					if (size > 4)
						if (g_loc == g_de - 1 && g_rc == ((size + 2) / 2 + 2))
							p = '$';
				}
	}
	ft_putchar(p);
}

void	ft_reset_counters(int type)
{
	g_loc = 1;
	if (type == 1)
	{
		g_width += 2;
		g_rc += 1;
		g_spaces--;
		g_spacecount = 0;
	}
	else if (type == 2)
	{
		g_block++;
		g_rows++;
		g_rc = 1;
		g_spaces -= 2;
		if (g_block > 3)
		{
			if (g_block % 2 == 0)
				g_width_increment += 2;
			if (g_block >= 6)
				g_spaces = g_spaces - ((g_block / 2) - 1);
			else
				g_spaces--;
		}
		g_width += g_width_increment;
	}
}

void	sastantua(int size)
{
	ft_init_counters(size);
	while (g_block <= size)
	{
		while (g_rc <= g_rows)
		{
			while (g_spacecount < g_spaces)
			{
				ft_putchar(' ');
				g_spacecount++;
			}
			while (g_loc <= g_width)
			{
				ft_print(size);
				g_loc++;
			}
			ft_reset_counters(1);
			ft_putchar('\n');
		}
		ft_reset_counters(2);
	}
}
