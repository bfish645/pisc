/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 18:29:57 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 18:29:58 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>

int	ft_putnbr(int nbr);
int ft_putchar(char c);
int	ft_atoi(char *str);
int	ft_add(int x, int y);
int	ft_minus(int x, int y);
int	ft_multiply(int x, int y);
int	ft_divide(int x, int y);
int	ft_modulo(int x, int y);
#endif
