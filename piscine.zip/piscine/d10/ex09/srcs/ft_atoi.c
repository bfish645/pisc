/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 08:57:36 by agraham           #+#    #+#             */
/*   Updated: 2016/08/12 08:57:40 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#define WS(c) (c == '\t'||c == '\n'||c == '\v'||c == '\f'||c == '\r'||c == ' ')

int	ft_atoi(char *str)
{
	unsigned long long	r;
	int					i;
	int					sign;

	r = 0;
	i = 0;
	sign = 1;
	while (WS(str[i]))
		str++;
	if (str[i] == '-' || str[i] == '+')
	{
		sign = str[i] == '-' ? -1 : 1;
		str++;
	}
	while (*str == '0')
		str++;
	while (str[i] != '\0')
	{
		if (str[i] > 57 || str[i] < 48)
			return (r * sign);
		r = r * 10 + (str[i++] - 48);
	}
	if (i > 19 || r > 9223372036854775807ULL)
		return (sign == 1 ? -1 : 0);
	return (r * sign);
}
