#include <stdio.h>
int ft_count_if(char **tab, int(*f)(char*));

int ft_is_a(char *c)
{
	int i = 0;

	while (c[i]){ 
		if(c[i] == 'a')
			return (1);
		i++;
	}
	return (0);
}

int	main(void)
{
	int result;
	char *tab[] = {"ahe222aallo","yab","teragy",0};
	
	result = ft_count_if(tab, &ft_is_a);
	printf("r= %d\n",result);
	
	return (0);
}