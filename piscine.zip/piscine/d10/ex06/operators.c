/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operators.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 18:42:22 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 18:42:23 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_add(int x, int y)
{
	return (x + y);
}

int	ft_minus(int x, int y)
{
	return (x - y);
}

int	ft_multiply(int x, int y)
{
	return (x * y);
}

int	ft_divide(int x, int y)
{
	return (x / y);
}

int	ft_modulo(int x, int y)
{
	return (x % y);
}
