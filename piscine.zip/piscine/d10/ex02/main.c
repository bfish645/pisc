/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 14:35:03 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 14:35:04 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int *ft_map(int *tab, int len, int(*f)(int));
#include <stdio.h>

int ft_x100(int n)
{
	return (n);
}

int	main(void)
{
	int *result;
	int i;
	int tab[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
	
	result = ft_map(tab, 18, ft_x100);
	
	

	i = 0;
	while (i < 18){
		printf("i: %d = %d\n",i,result[i]);
		i++;
	}
	return (0);
}
