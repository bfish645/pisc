/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/16 18:36:15 by agraham           #+#    #+#             */
/*   Updated: 2016/08/16 18:36:32 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int	main(void)
{
	char cmp[] = "hello";
	char cmp1[] = "hello";
	int a = 1;
	int b = 2;

	ft_putchar('p');
	ft_putchar('\n');
	ft_putstr("ft_putstr");
	ft_putchar('\n');
	ft_strcmp(cmp,cmp1);
	ft_putchar('\n');
	ft_strlen("hello");
	ft_putchar('\n');
	ft_swap(&a,&b);

	return (0);
}
