#include <stdio.h>
void 	ft_putchar(char c);
 
void 	ft_putnbr(int n)
{
  printf("%i",n);
}