/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 21:10:33 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 21:10:34 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
char	**ft_split_whitespaces(char *str);
void	ft_sort_wordtab(char **str);
int	main(void)
{
	char **tab = ft_split_whitespaces("zzzhello yyworld andrew ddoor  111");
	int i = 0;
	ft_sort_wordtab(tab);
	while(tab[i] != 0)
	{
		printf("Table element: %s\n", tab[i]);
		i++;
	}

}
