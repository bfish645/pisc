/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 17:55:56 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 17:55:57 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int trend;
	int difference;
	int i;

	trend = 0;
	i = 0;
	while (i + 1 < length)
	{
		difference = f(tab[i], tab[i + 1]);
		if ((difference > 0 && trend < 0) || (difference < 0 && trend > 0))
			return (0);
		if (difference < 0)
			trend = -1;
		else if (difference > 0)
			trend = 1;
		i++;
	}
	return (1);
}
