#include <stdio.h>
int	ft_is_sort(int *tab, int length, int (*f)(int, int));

int ft_is_greater(int x, int y)
{
	return (x - y);  
}

int main(void)
{
	int tab[] = {5,4,3,2,-50};
	int r;

	r = ft_is_sort(tab, 5, &ft_is_greater);
	printf("r: %d\n", r);

	return (0);
}
