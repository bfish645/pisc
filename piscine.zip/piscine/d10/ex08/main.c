/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 21:10:33 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 21:10:34 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
char	**ft_split_whitespaces(char *str);
void	ft_advanced_sort_wordtab(char **str, int (*cmp)(char *, char *));

int		ft_strcmp(char *s1, char *s2)
{
	unsigned char	a;
	unsigned char	b;
	int				i;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		a = s1[i];
		b = s2[i];
		if (a != b)
			return (a - b);
		i++;
	}
	return (0);
}

int	main(void)
{
	char **tab = ft_split_whitespaces("zzzhello yyworld andrew ddoor  111");
	int i = 0;
	ft_advanced_sort_wordtab(tab, &ft_strcmp);
	while(tab[i] != 0)
	{
		printf("Table element: %s\n", tab[i]);
		i++;
	}

}
