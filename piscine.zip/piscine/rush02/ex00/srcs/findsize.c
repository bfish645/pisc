/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   findsize.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vyudushk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/28 12:13:27 by vyudushk          #+#    #+#             */
/*   Updated: 2016/08/28 13:47:18 by vyudushk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		find_col(char *str)
{
	int		n;

	n = 0;
	while (str[n] != '\n')
		n++;
	return (n);
}

int		find_row(char *str)
{
	int		n;
	int		count;

	n = 0;
	count = 0;
	while (str[n] != '\0')
	{
		n++;
		if (str[n] == '\n')
			count++;
	}
	return (count);
}
