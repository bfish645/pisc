/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/28 14:04:57 by agraham           #+#    #+#             */
/*   Updated: 2016/08/28 14:04:58 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ft.h>

void	print_rush(int rush, int rows, int cols)
{
	ft_putstr("[rush-0");
	ft_putnbr(rush);
	ft_putstr("] [");
	ft_putnbr(cols);
	ft_putstr("] [");
	ft_putnbr(rows);
	ft_putstr("]");
}

void	print_new_line(void)
{
	ft_putchar('\n');
}

void	print_or(void)
{
	ft_putstr(" || ");
}

void	print_all(int rush, int rows, int cols)
{
	if (rush == 6 || rush == 7)
	{
		print_rush(rush == 6 ? 2 : 3, rows, cols);
		print_or();
		print_rush(4, rows, cols);
	}
	else if (rush == 9)
	{
		print_rush(2, rows, cols);
		print_or();
		print_rush(3, rows, cols);
		print_or();
		print_rush(4, rows, cols);
	}
	else
	{
		print_rush(rush, rows, cols);
	}
	print_new_line();
}
