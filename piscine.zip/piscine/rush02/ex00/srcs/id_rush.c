/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   id_rush.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vyudushk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/28 12:42:53 by vyudushk          #+#    #+#             */
/*   Updated: 2016/08/28 22:15:36 by vyudushk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ft.h>

int		id_rush00(char *str, int rows, int col)
{
	int i;
	int rc;
	int cc;

	i = 0;
	rc = 1;
	cc = 1;
	while (str[i] != '\0')
	{
		if ((((rc == 1 && cc == 1) || (rc == rows && cc == 1) ||
			(rc == 1 && cc == col) || (rc == rows && cc == col)) &&
			str[i] != 'o' && cc <= col) || ((rc == 1 || rc == rows) && cc != 1
			&& cc != col && str[i] != '-' && cc <= col) || ((cc == 1 ||
			cc == col) && rc != 1 && rc != rows && str[i] != '|'
			&& cc <= col) || (cc != 1 && cc != col && rc != 1 &&
			rc != rows && str[i] != ' ' && cc <= col))
			return (0);
		cc = str[i] == '\n' ? 1 : cc + 1;
		rc = str[i] == '\n' ? rc + 1 : rc;
		i++;
	}
	return (1);
}

int		id_rush01(char *str, int rows, int columns)
{
	int i;
	int rc;
	int cc;

	i = 0;
	rc = 1;
	cc = 1;
	while (str[i] != '\0')
	{
		if ((((rc == 1 && cc == 1) || (rc == rows && cc == columns && rows > 1
			&& columns > 1)) && str[i] != '/' && cc <= columns) || (((rc == 1
			&& cc == columns && columns > 1) || (rc == rows && cc == 1 &&
			rows > 1)) && str[i] != '\\' && cc <= columns) || ((((rc == 1 ||
			rc == rows) && (cc != 1 && cc != columns)) || (((cc == 1 ||
			cc == columns) && (rc != 1 && rc != rows)))) && str[i] != '*' &&
			cc <= columns)
			|| ((cc != 1 && cc != columns && rc != 1 && rc != rows &&
			str[i] != ' ' && cc <= columns)))
			return (0);
		cc = str[i] == '\n' ? 1 : cc + 1;
		rc = str[i] == '\n' ? rc + 1 : rc;
		i++;
	}
	return (1);
}

int		id_rush02(char *str, int rows, int columns)
{
	int i;
	int rc;
	int cc;

	i = 0;
	rc = 1;
	cc = 1;
	while (str[i] != '\0')
	{
		if ((((rc == 1 && cc == 1) || (rc == 1 && cc == columns)) &&
			str[i] != 'A' && cc <= columns) || (((rc == rows && cc == 1) ||
			(rc == rows && cc == columns)) && str[i] != 'C' && cc <= columns &&
			rows > 1) || ((((rc == 1 || rc == rows) && (cc != 1 &&
			cc != columns)) || (((cc == 1 || cc == columns) && (rc != 1 &&
			rc != rows)))) && str[i] != 'B' && cc <= columns)
			|| ((cc != 1 && cc != columns && rc != 1 && rc != rows &&
			str[i] != ' ' && cc <= columns)))
			return (0);
		cc = str[i] == '\n' ? 1 : cc + 1;
		rc = str[i] == '\n' ? rc + 1 : rc;
		i++;
	}
	return (1);
}

int		id_rush03(char *str, int rows, int columns)
{
	int i;
	int rc;
	int cc;

	i = 0;
	rc = 1;
	cc = 1;
	while (str[i] != '\0')
	{
		if ((((rc == 1 && cc == 1) || (rc == rows && cc == 1)) && str[i] != 'A'
			&& cc <= columns) || (((rc == rows && cc == columns && columns != 1)
			|| (rc == 1 && cc == columns && columns > 1)) && str[i] != 'C' &&
			cc <= columns) || ((((rc == 1 || rc == rows) && (cc != 1 &&
			cc != columns)) || (((cc == 1 || cc == columns) && (rc != 1 &&
			rc != rows)))) && str[i] != 'B' && cc <= columns)
			|| ((cc != 1 && cc != columns && rc != 1 && rc != rows &&
			str[i] != ' ' && cc <= columns)))
			return (0);
		cc = str[i] == '\n' ? 1 : cc + 1;
		rc = str[i] == '\n' ? rc + 1 : rc;
		i++;
	}
	return (1);
}

int		id_rush04(char *str, int rows, int columns)
{
	int i;
	int rc;
	int cc;

	i = 0;
	rc = 1;
	cc = 1;
	while (str[i] != '\0')
	{
		if ((((rc == 1 && cc == 1) || (rc == rows && cc == columns && rows > 1
			&& columns > 1)) && str[i] != 'A' && cc <= columns)
			|| (((rc == 1 && cc == columns && columns > 1) || (rc == rows &&
			cc == 1 && rows > 1)) && str[i] != 'C' && cc <= columns)
			|| ((((rc == 1 || rc == rows) && (cc != 1 && cc != columns)) ||
			(((cc == 1 || cc == columns) && (rc != 1 && rc != rows)))) &&
			str[i] != 'B' && cc <= columns)
			|| ((cc != 1 && cc != columns && rc != 1 && rc != rows &&
			str[i] != ' ' && cc <= columns)))
			return (0);
		cc = str[i] == '\n' ? 1 : cc + 1;
		rc = str[i] == '\n' ? rc + 1 : rc;
		i++;
	}
	return (1);
}
