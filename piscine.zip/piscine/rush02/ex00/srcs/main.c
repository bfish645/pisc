/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/28 13:33:49 by agraham           #+#    #+#             */
/*   Updated: 2016/08/28 23:15:18 by vyudushk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ft.h>

int		id_rush(char *str, int rows, int cols)
{
	int rush;

	rush = -1;
	if (id_rush00(str, rows, cols))
		rush = 0;
	if (id_rush01(str, rows, cols))
		rush = rush == -1 ? 1 : rush + 1;
	if (id_rush02(str, rows, cols))
		rush = rush == -1 ? 2 : rush + 2;
	if (id_rush03(str, rows, cols))
		rush = rush == -1 ? 3 : rush + 3;
	if (id_rush04(str, rows, cols))
		rush = rush == -1 ? 4 : rush + 4;
	return (rush);
}

int		main(void)
{
	char	buffer[BUFF_SIZE + 1];
	int		rush;
	int		ret;

	ret = read(STDIN_FILENO, buffer, BUFF_SIZE);
	rush = id_rush(buffer, find_row(buffer), find_col(buffer));
	if (rush != -1)
		print_all(rush, find_row(buffer), find_col(buffer));
	else
		ft_putstr("aucune\n");
	return (0);
}
