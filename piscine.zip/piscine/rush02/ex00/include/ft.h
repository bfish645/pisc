/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vyudushk <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/28 11:57:40 by vyudushk          #+#    #+#             */
/*   Updated: 2016/08/28 23:15:10 by vyudushk         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# define BUFF_SIZE 8000000

# include <unistd.h>

int		ft_strcmp(char *s1, char *s2);
int		find_col(char *str);
int		find_row(char *str);
void	ft_putchar(char c);
void	ft_putstr(char *str);
void	ft_putnbr(int n);
void	print_all(int rush, int rows, int cols);
int		id_rush00(char *str, int rows, int columns);
int		id_rush01(char *str, int rows, int columns);
int		id_rush02(char *str, int rows, int columns);
int		id_rush03(char *str, int rows, int columns);
int		id_rush04(char *str, int rows, int columns);
#endif
