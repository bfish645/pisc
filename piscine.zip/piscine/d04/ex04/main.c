void ft_putnbr(int x);
int	ft_fibonacci(int nb);

int main(){
	int i;
	i = 0;

 	i = ft_fibonacci(15);
	ft_putnbr(i);
	return (0);
}