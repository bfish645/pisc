void ft_putnbr(int x);
int	ft_sqrt(int nb);

int main(){
	int i;
	i = 0;

 	i = ft_sqrt(0);
	ft_putnbr(i);
	return (0);
}