void ft_putnbr(int x);
int	ft_is_prime(int nb);

int main(){
	int i;
	i = 0;

 	i = ft_is_prime(3);
	ft_putnbr(i);
	return (0);
}