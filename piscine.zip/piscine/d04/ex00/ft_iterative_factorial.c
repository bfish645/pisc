/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 13:53:14 by agraham           #+#    #+#             */
/*   Updated: 2016/08/12 13:53:20 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int i;
	int result;

	i = 1;
	result = nb;
	if (nb <= 0 || nb > 12)
	{
		nb = 0;
	}
	while (i < nb - 1 && result != 0)
	{
		result = result * (nb - i);
		i++;
	}
	return (result);
}
