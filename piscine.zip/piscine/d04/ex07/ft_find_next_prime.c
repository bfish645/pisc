/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/13 13:59:56 by agraham           #+#    #+#             */
/*   Updated: 2016/08/13 14:00:12 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int i;

	i = 2;
	if (nb < 1)
	{
		return (0);
	}
	while (i < nb)
	{
		if (nb % i == 0)
			return (0);
		else
			i += 1;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	int i;

	i = nb;
	if (ft_is_prime(nb))
	{
		return (nb);
	}
	else if (nb % 2 == 0)
	{
		nb += 1;
	}
	while (i < 2147483647)
	{
		if (ft_is_prime(nb) == 1)
			return (nb);
		nb += 2;
	}
	return (0);
}
