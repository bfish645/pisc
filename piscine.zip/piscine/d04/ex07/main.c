void ft_putnbr(int x);
int	ft_find_next_prime(int nb);

int main(){
	int i;
	i = 0;

 	i = ft_find_next_prime(942);
	ft_putnbr(i);
	return (0);
}