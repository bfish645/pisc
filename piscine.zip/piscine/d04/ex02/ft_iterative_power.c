/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 14:28:30 by agraham           #+#    #+#             */
/*   Updated: 2016/08/12 14:28:47 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int i;
	int result;

	i = 1;
	result = nb;
	if (power < 0)
		result = 0;
	else if (power == 0)
		result = 1;
	while (i < power && result != 0 && power != 0)
	{
		result = result * nb;
		i++;
	}
	return (result);
}
