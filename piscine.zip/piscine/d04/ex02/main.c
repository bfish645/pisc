void ft_putnbr(int x);
int	ft_iterative_power(int nb, int power);

int main(){
	int i;
	i = 3;

 	i = ft_iterative_power(i,0);
	ft_putnbr(i);
	return (0);
}