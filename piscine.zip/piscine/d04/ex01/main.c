void ft_putnbr(int x);
int	ft_recursive_factorial(int nb);

int main(){
	int i;
	i = 13;

 	i = ft_recursive_factorial(i);
	ft_putnbr(i);
	return (0);
}