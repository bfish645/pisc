void ft_putnbr(int x);
int	ft_recursive_power(int nb, int power);

int main(){
	int i;
	i = 5;

 	i = ft_recursive_power(i,3);
	ft_putnbr(i);
	return (0);
}