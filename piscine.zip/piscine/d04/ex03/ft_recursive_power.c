/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 16:21:10 by agraham           #+#    #+#             */
/*   Updated: 2016/08/12 16:21:13 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		nb = 0;
	else if (power == 0)
		nb = 1;
	if (power > 1)
	{
		nb = ft_recursive_power(nb, power - 1) * nb;
	}
	return (nb);
}
