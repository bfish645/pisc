/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helper.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 18:02:02 by agraham           #+#    #+#             */
/*   Updated: 2016/08/27 18:02:32 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>
#include <stdio.h>
#include "ft.h" 
int ft_strlen(char *str);
char *ft_remove_spaces(char *str)
{
	char *new_str;
	int i;
	int j;

	new_str = malloc(sizeof(char) * ft_strlen(str));
	if(new_str)
	{
		i = 0;
		j = 0;
		while(str[i] != '\0')
		{
			if(str[i] != ' ')
			{
				new_str[j] = str[i];
				i++;
				j++; 
			}
			else
				i++;
		}
		new_str[j] = '\0';
	}
	return (new_str);
}

void ft_push(t_stack *stack, int value, char operator)
{
	t_stack *element;

	element = malloc(sizeof(t_stack));

	element->value = value;
	element->op = operator;
	stack->next = element;
}

t_stack *ft_pop(t_stack *stack)
{
	t_stack *last;

	while(stack->next->next)
		stack = stack->next;
	last = stack->next->next;
	stack->next = NULL;
	return (last);
}

int ft_is_num(char c)
{
	return (c >= 48 && c <= 57) ? 1 : 0;
}

int ft_is_op(char c)
{	
	int r;

	r = 0;
	if(c == 37)
		r = 1;
	else if(c >= 40 && c <= 45)
		r = 1;
	return (r);
}

int ft_is_right_br(char c)
{
	return c == 41 ? 1 : 0;
}

int ft_is_left_br(char c)
{
	return c == 40 ? 1 : 0;
}

char ft_get_opp(char *str, int index)
{

	r = 0;
	while(ft_is_num(str[index]))
	{
		r = r * 10;
		r += (str[index] - 48);
		index++;
	}
	return (r);
}
int ft_get_num(char *str, int index)
{
	int r;

	r = 0;
	while(ft_is_num(str[index]))
	{
		r = r * 10;
		r += (str[index] - 48);
		index++;
	}
	return (r);
}

