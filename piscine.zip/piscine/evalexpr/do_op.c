/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_op.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 18:12:04 by agraham           #+#    #+#             */
/*   Updated: 2016/08/22 18:12:13 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft.h"

int	ft_invalid_operator(int x, int y)
{
	(void)x;
	(void)y;
	return (0);
}

int	ft_op(char *c)
{
	if (c[0] == '+')
		return (1);
	else if (c[0] == '-')
		return (2);
	else if (c[0] == '*')
		return (3);
	else if (c[0] == '/')
		return (4);
	else if (c[0] == '%')
		return (5);
	else
		return (0);
}

int	ft_calc(int x, int (*o)(int, int), int y)
{
	return (o(x, y));
}

int	do_op(int x, char opp, int y)
{
	int (*o[6])(int x, int y);
	int r;

	o[0] = &ft_invalid_operator;
	o[1] = &ft_add;
	o[2] = &ft_minus;
	o[3] = &ft_multiply;
	o[4] = &ft_divide;
	o[5] = &ft_modulo;
	
	r = ft_calc(x, o[ft_op(opp)], y);
			
	return (r);
}
