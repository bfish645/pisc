/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 16:26:25 by agraham           #+#    #+#             */
/*   Updated: 2016/08/27 16:26:29 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ft.h"

t_stack *g_val_stack;
t_stack *g_op_stack;

void ft_process_bracket()
{
	t_stack *opp;

	opp = ft_pop(g_op_stack)->op 
	while(opp->op != '(')
	{
		int value;
		t_stack *x; 
		t_stack *y;

		y = ft_pop(*g_val_stack);
		x = ft_pop(*g_val_stack);
		value =  do_op(x->value, opp->op, y->value);
		free(x);
		free(y);
		ft_push(g_val_stack, value, NULL);
	}
	free(ft_pop(g_op_stack))
}
char *ft_eval_expr(char *str)
{
	int i = 0;

	while(str[i] != '\0')
	{
		if(ft_is_num(str[i]))
			ft_push(g_val_stack, ft_get_num(str, i), NULL);
		while(ft_is_num(str[i]))
			i++;
		if(ft_is_op(str[i]))
			if(ft_is_right_br(str[i]))
				ft_process_bracket()
			else
				ft_push(g_op_stack, NULL, ft_get_op(str, i))
			
		i++;
	}
	return (str);

}
int	main(int ac, char **av)
{
	char *str = "42";
	str = ft_remove_spaces(str);
	printf("Without spaces: %s\n", str);
	printf("Get number: %d", ft_get_num("420000",0));
	/*if (ac > 1)
	{
		while(*eval_expr(av[1]))
		{
			write(1, eval_expr(av[1]), sizeof(char));
			*eval_expr(av[1])++;
		}
		write("\n");
	}
  	return (0);
  	*/
  	return (0);
}
