/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 19:57:58 by agraham           #+#    #+#             */
/*   Updated: 2016/08/27 19:58:00 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>
# include <stdlib.h>
typedef struct	s_stack
{
	struct s_stack	*next;
	int				value;
	char 			op;
}				t_stack;

char *ft_remove_spaces(char *str);
int ft_get_num(char *str, int index);
int ft_is_num(char c);
void ft_push(t_stack *stack, int value);

#endif
