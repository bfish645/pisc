/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/10 19:49:45 by agraham           #+#    #+#             */
/*   Updated: 2016/08/10 21:35:20 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

int		ft_setdivider(int nb)
{
	int divider;

	divider = 1;
	while (nb >= 10)
	{
		nb = nb / 10;
		divider = divider * 10;
	}
	return (divider);
}

int		ft_negativeorexception(int nb)
{
	if (nb == -2147483648)
	{
		ft_putchar('-');
		ft_putchar('2');
		ft_putchar('1');
		ft_putchar('4');
		ft_putchar('7');
		ft_putchar('4');
		ft_putchar('8');
		ft_putchar('3');
		ft_putchar('6');
		ft_putchar('4');
		ft_putchar('8');
	}
	else if (nb < 0)
	{
		ft_putchar('-');
		nb = nb * -1;
	}
	return (nb);
}

void	ft_putnbr(int nb)
{
	int divider;

	if (nb < 0)
		nb = ft_negativeorexception(nb);
	divider = ft_setdivider(nb);
	while (divider > 0)
	{
		if (nb / divider >= 0)
		{
			ft_putchar(nb / divider + 48);
			nb = nb % divider;
		}
		divider = divider / 10;
	}
}
