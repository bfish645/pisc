/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/10 18:16:04 by agraham           #+#    #+#             */
/*   Updated: 2016/08/10 19:35:18 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	delimit(void)
{
	ft_putchar(',');
	ft_putchar(' ');
}

void	ft_print_comb2(void)
{
	int x;
	int y;

	x = 0;
	y = 0;
	while (x <= 99)
	{
		while (y <= 99)
		{
			if (x != y)
			{
				ft_putchar(x / 10 + 48);
				ft_putchar(x % 10 + 48);
				ft_putchar(' ');
				ft_putchar(y / 10 + 48);
				ft_putchar(y % 10 + 48);
				if (x != 98 || y != 99)
					delimit();
			}
			y++;
		}
		x++;
		y = x;
	}
}
