/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/10 15:41:40 by agraham           #+#    #+#             */
/*   Updated: 2016/08/10 16:10:33 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	ft_is_negative(int number)
{
	if (number > 0 || !number)
	{
		ft_putchar('P');
	}
	else if (number < 0)
	{
		ft_putchar('N');
	}
}
