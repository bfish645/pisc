/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agraham <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/10 19:49:45 by agraham           #+#    #+#             */
/*   Updated: 2016/08/10 23:47:39 by agraham          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

int		ft_xtenandadd(int factor, int addend)
{
	int result;

	result = factor * 10;
	result += addend;
	return (result);
}

void	ft_putnbr(int nb)
{
	int initial;
	int reversed;

	initial = nb;
	reversed = 0;
	while (nb != 0)
	{
		if ((nb < 10 && nb > 0) || (nb > -10 && nb < 0 ))
			reversed = ft_xtenandadd(reversed, nb);
		else
			reversed = ft_xtenandadd(reversed, nb % 10);
		nb = nb / 10;
	}
	while (reversed != 0)
	{
		if(initial < 0){
			ft_putchar(((reversed % 10) * - 1) + 48);
		}else{
			ft_putchar(reversed % 10 + 48);
		}
		reversed = reversed / 10;
	}
}
